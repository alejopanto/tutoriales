<?php $__env->startSection('app'); ?>
    <table-component></table-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aletop/Prueba_conocimiento/resources/views/table.blade.php ENDPATH**/ ?>