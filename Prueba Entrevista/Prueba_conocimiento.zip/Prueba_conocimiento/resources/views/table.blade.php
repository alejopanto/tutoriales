@extends('layout.layout')
@section('app')
    <table-component></table-component>
@endsection